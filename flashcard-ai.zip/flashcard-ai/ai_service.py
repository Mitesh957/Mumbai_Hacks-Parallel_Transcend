from transformers import pipeline, AutoTokenizer, AutoModelForCausalLM
import random

class FlashcardGenerator:
    def __init__(self):
        # Initialize with proper configuration
        self.tokenizer = AutoTokenizer.from_pretrained('gpt2')
        self.model = AutoModelForCausalLM.from_pretrained('gpt2')
        self.generator = pipeline('text-generation',
                                model=self.model,
                                tokenizer=self.tokenizer,
                                truncation=True)  # Add explicit truncation
        
    def generate_content(self, topic):
        prompt = f"Create educational flashcards about {topic}. ."
        
        try:
            # Generate content with proper error handling
            response = self.generator(
                prompt,
                max_length=200,
                num_return_sequences=3,
                pad_token_id=self.tokenizer.eos_token_id
            )
            
            cards = []
            for text in response:
                content = text['generated_text'].split('.')
                if len(content) >= 2:
                    cards.append({
                        'question': content[0].strip(),
                        'answer': '.'.join(content[1:]).strip(),
                        'difficulty': random.choice(['easy', 'medium', 'hard'])
                    })
            
            return cards
        except Exception as e:
            print(f"Content generation error: {str(e)}")
            return []